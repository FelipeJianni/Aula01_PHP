<?php
	$arr1 = array("Gil", "Eduardo");
	$arr2 = array("Maria", "Claudia");

	print_r($arr1);
	echo "<br>";
	print_r($arr2);
	echo "<br>";

	$merge = array_merge($arr1, $arr2);
	print_r($merge);


