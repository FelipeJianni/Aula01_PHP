<?php
	$arr = array("id" => 1, "email" => "gil@gmail.com");
	print_r($arr);
	echo "<br>";

	$values = array_values($arr);
	print_r($values);


