<?php

	$str = "Gil, Eduardo, Andrade";
	print_r($str);
	echo "<br>";

	// Retorna um array
	$arr = explode(", ", $str);
	print_r($arr);