<?php
	$arr = array("id" => 1, "email" => "gil@gmail.com");
	print_r($arr);
	echo "<br>";

	$keys = array_keys($arr);
	print_r($keys);


