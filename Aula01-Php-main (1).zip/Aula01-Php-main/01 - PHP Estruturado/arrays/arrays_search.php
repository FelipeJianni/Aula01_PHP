<?php
	$arr = array("Gil", "Eduardo", "Andrade");

	print_r($arr);
	echo "<br>";

	$index = array_search("Eduardo", $arr);
	print_r($index);


