<?php

	$arr = array(
		array("nome" => "Gil"),
		array("nome" => "Eduardo")
	);
	print_r($arr);
	echo "<br>";

	array_push($arr, array("nome" => "Andrade"));
	print_r($arr);