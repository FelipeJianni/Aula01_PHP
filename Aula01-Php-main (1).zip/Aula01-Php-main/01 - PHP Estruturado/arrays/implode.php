<?php

	$arr = array("Gil", "Eduardo", "Andrade");
	print_r($arr);
	echo "<br>";

	// Retorna uma string
	$new_arr = implode(", ", $arr);
	print_r($new_arr);