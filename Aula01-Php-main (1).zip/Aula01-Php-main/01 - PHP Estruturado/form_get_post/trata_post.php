<?php
	echo $_POST['aluno'];
	echo "<br>";
	echo $_POST['turma'];
?>

