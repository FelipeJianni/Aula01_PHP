<?php
    echo "<script> window.location='viewMain.php' </script>";
?>
