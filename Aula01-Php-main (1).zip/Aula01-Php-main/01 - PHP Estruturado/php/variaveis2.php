<?php

	$var = "Gil Eduardo";	// String
	$tipo = gettype($var);
	echo "$var ($tipo)<br>";
	$var = 12;			// Inteiro
	$tipo = gettype($var);
	echo "$var ($tipo)<br>";
	$var = 3.1415;		// Float/Double
	$tipo = gettype($var);
	echo "$var ($tipo)<br>";
	$var = true;		// Booleano
	$tipo = gettype($var);
	echo "$var ($tipo)<br>";
?>


