<?php

	$curso = "Graduação em Análise e Desenvolvimento de Sistemas";
	$disciplina = "Desenvolvimento Web II";	
	$turma = 2015;	

	echo "[CURSO]: $curso<br>";
	echo "[DISCIPLINA]: $disciplina<br>";
	echo "[TURMA]: $turma";
?>


