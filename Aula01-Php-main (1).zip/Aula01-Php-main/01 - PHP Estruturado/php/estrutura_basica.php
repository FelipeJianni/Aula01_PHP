<?php
	echo "Hello";	
	print "World!";
?>


